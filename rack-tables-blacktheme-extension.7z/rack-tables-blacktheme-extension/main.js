try{
$('body').css('background', 'black');
$('.greynavbar').css('background', 'black');
$('.menubar').css('background', 'black');
$('tr').css('background', 'black');
$('tr').css('color', 'white');
$('th').css('border-bottom', '1px solid white');
$('td').css('color', 'white');
$('.portlet').css('background', 'black');
}catch(ex){

}